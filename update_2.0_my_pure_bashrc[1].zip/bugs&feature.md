dependencies
/system/bin/bash
/system/bin/bash.bin
/system/etc/bashrc
/system/etc/bash_logout

#bugs bashrc
## 11814 fixed
- "double execute" 
## 40054 fixed
- "$0 are bash.bin" 

# feature
## 87432 apply
- "clear screen"


